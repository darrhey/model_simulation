// id selections
const rangeEl = document.getElementById("range_val");
const rangeEl2 = document.getElementById("range_val2");
const rangeEl3 = document.getElementById("range_val3");
const rangeEl4 = document.getElementById("range_val4");
const tempEl = document.getElementById("temp_exceed");
const complEl = document.getElementById("compliance");
const windEl = document.getElementById("windspeed");
const SE_Map = document.getElementById("seMap");
const NW_Map = document.getElementById("nwMap");
let efrEL = document.getElementById("efr");
const comvalEL = document.getElementById("comval");
const minusCEl = document.getElementById("minus");
const plusCEl = document.getElementById("plus");


// Constants Declarations and assignments
const EFR_Coefficient = 2554.93; //H
const Pie_Constant = 1.57; //J
let EFR; //I
let Bound_Rad = [50,100,100,200,300]; //K
let Boundary_Radius;
let SD_NW = [20,19.8,19.5,19.3,19]; //L
let SeaDepth_NW;
let SD_SE = [20,20.3,20.5,20.8,21]; //M
let SeaDepth_SE;
let Non_Compliance; //B
let Temp_Exceed; //G
let speed;
let dilPercentNW;
let dilPercentSE;
let impactFactor;
let Non_ComplianceValue;

function complyplus(){
    let i = 0;
    Non_ComplianceValue=i;
    comvalEL.innerHTML=Non_Compliance;
    if(i<=10){
        i++;        
    }
    else{
        i=0;
    }
}
function complyminus(){
    while(i<=10){
        Non_ComplianceValue=i;
        comvalEL.innerHTML=Non_Compliance;
        i--;
    }
}

// let plume_lenght =[0,72,144,218,288];


// EcoRisk Formula Declaration 
let EcoRisk_NW;
let EcoRisk_SE;
let Signal_NW;
let Signal_SE;
let Signal_Speed;
setInterval((changeImage) => {
    //Time detection
    let now = new Date();
    let hours = now.getHours();

    //Change background with time
    if ((hours<=6)||(hours>=18)){
        document.getElementById("container").classList.add("container2");
    }
    else{
        document.getElementById("container").classList.add("container1");
    }
    speed = windEl.value;
    EFR = Number(efrEL.value);
    rangeEl.innerHTML = tempEl.value+"°C";
    rangeEl2.innerHTML = EFR;
    rangeEl3.innerHTML = Math.round(EcoRisk_NW*10000000)/10000000;
    rangeEl4.innerHTML = Math.round(EcoRisk_SE*10000000)/10000000;
    Temp_Exceed = tempEl.value;
    Non_Compliance = complEl.value;
    if (speed == 0.02){
        Signal_Speed=1;
    }
    else if(speed == 0.04){
        Signal_Speed=2;
    }
    else if(speed==0.06){
        Signal_Speed=3;
    }
    else if(speed==0.08){
        Signal_Speed=4;
    }
    SeaDepth_NW = SD_NW[Signal_Speed];
    SeaDepth_SE = SD_SE[Signal_Speed];
    Boundary_Radius = Bound_Rad[Signal_Speed];

    if (EcoRisk_NW<=25){
        Signal_NW = 1;
    }
    else if((EcoRisk_NW>25)&&(EcoRisk_NW<=38)){
        Signal_NW = 2;
    }
    else if ((EcoRisk_NW>38)&&(EcoRisk_NW<=51)){
        Signal_NW = 3;
    }
    else if(EcoRisk_NW>51){
        Signal_NW = 4;
    }
    else{
        Signal_NW = 0;
    }

    if (EcoRisk_SE<=25){
        Signal_SE = 1;
    }
    else if((EcoRisk_SE>25)&&(EcoRisk_SE<=38)){
        Signal_SE = 2;
    }
    else if ((EcoRisk_SE>38)&&(EcoRisk_SE<=51)){
        Signal_SE = 3;
    }
    else if(EcoRisk_SE>51){
        Signal_SE = 4;
    }
    else{
        Signal_SE = 0;
    }
    dilPercentNW = (EFR_Coefficient*EFR)/((Pie_Constant*SeaDepth_NW*Boundary_Radius**2)+EFR);
    dilPercentSE = (EFR_Coefficient*EFR)/((Pie_Constant*SeaDepth_SE*Boundary_Radius**2)+EFR);
    impactFactor = ((Non_Compliance*0.1)+(Temp_Exceed*0.1));
    EcoRisk_NW = dilPercentNW*(10**impactFactor);
    EcoRisk_SE = dilPercentSE*(10**(impactFactor));

    
    let S_E = "./model/SE/R1"+Signal_Speed+Signal_SE+".jpg"; 
    let N_W = "./model/NW/R2"+Signal_Speed+Signal_NW+".jpg";
    SE_Map.setAttribute("src", S_E);
    NW_Map.setAttribute("src", N_W);    
}, 10);
